document.getElementById('btn6').addEventListener('click', function(){
var preco=Number(document.getElementById('preco6').value);
var cod=document.getElementById('cod6').value;
var final=preco;
if(cod==='1') final=preco*(1-0.10);
else if(cod==='2') final=preco*(1-0.05);
else if(cod==='3') final=preco*(1+0.10);
document.getElementById('saida6').value = 'Preço real: R$ ' + preco.toFixed(2) + ' - Valor a pagar: R$ ' + final.toFixed(2);
});