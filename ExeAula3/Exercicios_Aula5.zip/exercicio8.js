document.getElementById('btn8').addEventListener('click', function(){
var s = Number(document.getElementById('sal8').value);
var taxa = 0;
if(s <= 1434) taxa = 0;
else if(s <= 2150) taxa = 7.5;
else if(s <= 2866) taxa = 15;
else if(s <= 3582) taxa = 22.5;
else taxa = 27.5;
var imposto = s * (taxa/100);
document.getElementById('ir8').value = 'Alíquota: ' + taxa + '% - IR: R$ ' + imposto.toFixed(2);
});