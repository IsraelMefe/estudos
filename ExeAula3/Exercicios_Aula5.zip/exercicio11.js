document.getElementById('btn11').addEventListener('click', function(){
var n = parseInt(document.getElementById('n11').value);
if(isNaN(n) || n<1){ document.getElementById('saida11').value='Informe N >= 1.'; return; }
var s = n*(n+1)/2;
document.getElementById('saida11').value = s;
});