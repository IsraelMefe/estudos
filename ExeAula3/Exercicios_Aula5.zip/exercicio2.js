document.getElementById('btn2').addEventListener('click', function(){
var n = parseInt(document.getElementById('num2').value);
if(Number.isNaN(n)){ document.getElementById('saida2').value = 'Digite um inteiro.'; return; }
document.getElementById('saida2').value = (n % 2 === 0) ? 'Par' : 'Ímpar';
});