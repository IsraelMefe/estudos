document.getElementById('btn1').addEventListener('click', function(){
var total = Number(document.getElementById('total').value);
var parcelas = parseInt(document.getElementById('parcelas').value);
var taxa = null;
if(parcelas === 1) taxa = 0;
else if(parcelas === 2) taxa = 3;
else if(parcelas === 4) taxa = 7;
else { document.getElementById('saida1').value = 'Parcelas permitidas: 1, 2 ou 4.'; return; }
var valorTotal = total * (1 + taxa/100);
var valorParcela = valorTotal / parcelas;
document.getElementById('saida1').value = 'Taxa: ' + taxa + '%\nValor total com juros: R$ ' + valorTotal.toFixed(2) + '\nValor por parcela: R$ ' + valorParcela.toFixed(2);
});