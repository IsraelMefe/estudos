document.getElementById('btn3').addEventListener('click', function(){
var a = Number(document.getElementById('a3').value);
var b = Number(document.getElementById('b3').value);
if(a > b) document.getElementById('saida3').value = 'Maior: ' + a;
else if(b > a) document.getElementById('saida3').value = 'Maior: ' + b;
else document.getElementById('saida3').value = 'São iguais';
});