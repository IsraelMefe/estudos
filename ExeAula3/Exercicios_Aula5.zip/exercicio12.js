var segredo=null; var tentativas=0;
document.getElementById('novo').addEventListener('click', function(){
segredo = Math.round(Math.random()*100);
tentativas = 0;
document.getElementById('saida12').value = 'Novo jogo iniciado.';
});
document.getElementById('btn12').addEventListener('click', function(){
if(segredo===null){ document.getElementById('saida12').value='Clique em Novo jogo antes de chutar.'; return; }
var chute = parseInt(document.getElementById('chute').value);
if(isNaN(chute)){ document.getElementById('saida12').value='Informe um número.'; return; }
tentativas++;
if(chute === segredo){
var msg = 'Acertou! Tentativas: ' + tentativas;
document.getElementById('saida12').value = msg;
if(confirm('Deseja jogar novamente?')){ segredo = Math.round(Math.random()*100); tentativas = 0; document.getElementById('saida12').value = 'Novo jogo iniciado.'; } else segredo = null;
} else if(chute < segredo) document.getElementById('saida12').value = 'O número é maior.';
else document.getElementById('saida12').value = 'O número é menor.';
});