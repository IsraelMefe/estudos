document.getElementById('btn4').addEventListener('click', function(){
var b = Number(document.getElementById('base4').value);
var h = Number(document.getElementById('alt4').value);
if(Number.isNaN(b) || Number.isNaN(h)){ document.getElementById('saida4').value='Informe base e altura.'; return; }
document.getElementById('saida4').value = 'Área = ' + (b*h).toFixed(2);
});