document.getElementById('btn7').addEventListener('click', function(){
var h=Number(document.getElementById('alt7').value);
var p=Number(document.getElementById('peso7').value);
var s=document.getElementById('sexo7').value;
if(!h || !p){ document.getElementById('saida7').value='Informe altura e peso.'; return; }
var imc = p / (h*h);
var cat = '';
if(s==='F'){
  if(imc < 19.1) cat='Abaixo do peso';
  else if(imc < 25.8) cat='Peso normal';
  else if(imc < 27.3) cat='Marginalmente acima do peso';
  else if(imc < 32.3) cat='Acima do peso ideal';
  else cat='Obeso';
} else {
  if(imc < 20.7) cat='Abaixo do peso';
  else if(imc < 26.4) cat='Peso normal';
  else if(imc < 27.8) cat='Marginalmente acima do peso';
  else if(imc < 31.1) cat='Acima do peso ideal';
  else cat='Obeso';
}
document.getElementById('saida7').value = 'IMC: ' + imc.toFixed(2) + '\nCategoria: ' + cat;
});