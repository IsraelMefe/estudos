document.getElementById('btn10').addEventListener('click', function(){
var n = parseInt(document.getElementById('n10').value);
if(isNaN(n) || n<0){ document.getElementById('saida10').value='Informe N inteiro e não-negativo.'; return; }
var f=1;
for(var i=2;i<=n;i++) f*=i;
document.getElementById('saida10').value = f;
});