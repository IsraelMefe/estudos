document.getElementById('btn5').addEventListener('click', function(){
var n1=Number(document.getElementById('n51').value);
var n2=Number(document.getElementById('n52').value);
var n3=Number(document.getElementById('n53').value);
var media=(n1+n2+n3)/3;
var conceito='';
if(media>=6) conceito='APROVADO';
else if(media>=3) conceito='EXAME';
else conceito='REPROVADO';
document.getElementById('saida5').value = media.toFixed(2) + ' - ' + conceito;
});